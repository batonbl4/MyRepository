#include <iostream>
#include "sqlite3.h"
#include <string>
#include <conio.h>
#include "keynumb.h"
#include <locale>
#include <iomanip>


using namespace std;
wstring UserName; //Логин
wstring UserPass; //Пароль
wstring SecretNumber; //Загаданное число
wstring UserNumb;//Число вводимое пользователем
wchar_t* WUserName;//Логин
wchar_t* WUserPass;//Пароль

KeyNumb SecretNumb(4);

wchar_t authorization;
wchar_t start;
MyDataBase MYDB;
double Try = 0; //кол-во попыток угадать число за игру

char Select;
wchar_t* DataBaseName = (wchar_t*)L"DATABASE.DB";
void Exit();

int main()
{ 
    setlocale(LC_ALL,"ru_RU.UTF-8");


    if(MYDB.OpenDataBase(DataBaseName))
    {
        MYDB.CreateTable();
    }
    else
    {
        wcout<<L"Ошибка базы данных"<<endl;
    }

    do
    {
        wcout<<L"Войти - 1    Регистрация - 2    Выйти - 3"<< endl;
        authorization = getch();
        bool checklogin; //флаг проверки на совпадение имени пользователя
        switch (authorization )
        {
        case '1':   do
                    {
                        wcout<<L"Логин: ";
                        wcin>>UserName;
                        WUserName = (wchar_t*)UserName.c_str();
                        wcout<<L"Пароль: ";
                        wcin>>UserPass;
                        WUserPass = (wchar_t*)UserPass.c_str();
                        if(!MYDB.CheckUserLoginPass(WUserName,WUserPass))
                        {
                            wcout<<L"Неверная пара Логин/Пароль"<<endl;
                            wcout<<L"Повторить вход? (Y/N)"<<endl;
                            checklogin = false;
                            Select = getch();
                            if(Select =='n'||Select =='N')
                                break;
                        }
                        else
                            checklogin = true;

                    }
                    while(!checklogin);
                    break;

        case '2':   do
                    {
                        wcout<<L"Регистрация пользователя"<< endl;
                        wcout<<L"Логин: ";
                        wcin>>UserName;
                        WUserName = (wchar_t*)UserName.c_str();
                        wcout<<L"Пароль: ";
                        wcin>>UserPass;
                        WUserPass = (wchar_t*)UserName.c_str();

                        if(!MYDB.CreateUser(WUserName,WUserPass))
                        {
                            wcout<<L"Пользователь с таким именем уже существует"<<endl;
                            wcout<<L"Повторить регистрацию(Y/N)"<<endl;
                            checklogin = false;
                            Select = getch();
                            if(Select =='n'||Select =='N')
                               break;

                        }
                        else
                            checklogin = true;

                    }
                    while(!checklogin);
                    break;

        default:    Exit(); break;
        }
    }
    while(Select =='n'||Select =='N');

    wcout<<L"Начать игру? (Y/N)"<<endl;
    Select = getch();
    if(Select=='y'||Select=='Y')//Тело игры
    {
        do
        {
            MYDB.GetData(WUserName);
            Try = 0; //Новая игра, обнуляем кол-во попыток
            SecretNumber = SecretNumb.GetSecretNumb();// получить загаданное число
            wcout<<L"Введите число из " + SecretNumb.IntToStr(SecretNumb.GetCounter()) + L" цифр:"<<endl;

            do
            {
                ++Try;//Инкрементируем кол-во попыток
                UserNumb.clear();//очистить число вводимое пользователем
                for(int i=0; i<SecretNumb.GetCounter(); i++)
                {
                    wchar_t Numb = getch();//захват символа
                    if(Numb<'0'||Numb>'9')//Если символ не цифра, то вывести 0
                        Numb = '0';
                    UserNumb = UserNumb + Numb;
                    wcout<<Numb;//вывод пользовательского числа
                }
                wcout<<L" -- " + SecretNumb.Compare(UserNumb)<<endl;//сравнить загаданное число с числом введенное пользователем
            }
            while(SecretNumber!=UserNumb);//продолжать пока число не угадано
            wcout<<L"Число угадано"<<endl;
            wcout<<L"Попыток: "<<Try<<endl;
            MYDB.SetData(Try, WUserName);
            wcout<<L"Повторить? (Y/N)"<<endl;
            Select = getch();
        }
        while(Select =='y'||Select =='Y');//начать новую игру если Y
        Exit();
    }
    else
        Exit();

    Exit();
    return 0;

}
//-------------------------------------------------
void Exit()
{
    sqlite3_close(MYDB.DB);
    exit(0);
}
