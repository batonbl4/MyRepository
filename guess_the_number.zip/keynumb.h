#ifndef KEYNUMB_H
#define KEYNUMB_H
#include <string>
#include "sqlite3.h"
class KeyNumb
{
public:
    KeyNumb(int N = 4);
    std::wstring GetSecretNumb();
    std::wstring Compare(std::wstring UserNumb);
    int GetCounter();
    std::wstring IntToStr(int numb);
private:
    int counter;
    std::wstring SecretNumb;

};


class MyDataBase
{
public:
    /*
    bool OpenDataBase(wchar_t* Name,  sqlite3* DB);
    void CreateTable(sqlite3_stmt *stmtU, sqlite3* DB);
    bool CreateUser(wchar_t* Name, wchar_t* passw, sqlite3_stmt *stmtU, sqlite3* DB);
    bool CheckUserLoginPass(wchar_t* Name, wchar_t* passw, sqlite3_stmt *stmtU, sqlite3* DB);
    int GetTry(wchar_t* Name, wchar_t* passw, sqlite3_stmt *stmtU, sqlite3* DB);
    int GetWins(wchar_t* Name, wchar_t* passw, sqlite3_stmt *stmtU, sqlite3* DB);
    double GetRatio(wchar_t* Name, wchar_t* passw, sqlite3_stmt *stmtU, sqlite3* DB);
    void SetTry(int t, wchar_t* Name, wchar_t* passw, sqlite3_stmt *stmtU, sqlite3* DB);
    void SetWins(int w, wchar_t* Name, wchar_t* passw, sqlite3_stmt *stmtU, sqlite3* DB);
    void SetRatio(double r, wchar_t* Name, wchar_t* passw, sqlite3_stmt *stmtU, sqlite3* DB);
    */
    bool OpenDataBase(wchar_t* Name);
    void CreateTable();
    bool CreateUser(wchar_t* Name, wchar_t* passw);
    bool CheckUserLoginPass(wchar_t* Name, wchar_t* passw);
    void GetData(wchar_t* Name);
    void SetData(double t, wchar_t* Name);
    sqlite3 *DB;
    sqlite3_stmt *stmtU;
private:
    double Try; //общее кол-во попыток
    double Wins; // кол-во угаданных чисел
    double Ratio; // среднее кол-во попыток
};
#endif // KEYNUMB_H
