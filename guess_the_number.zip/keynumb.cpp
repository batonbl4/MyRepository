#include "keynumb.h"
#include "cstdlib"
#include "sstream"
#include "ctime"
#include <iostream>
//#include "sqlite3.h"

KeyNumb::KeyNumb(int N)
{
    srand(time(NULL));
    if(N>10)
        N=10;
    if(N<1)
        N=1;
    counter = N;
}
//----------------------------------------------------------
std::wstring KeyNumb::GetSecretNumb()
{
    int i = 1;
    bool Check = true;
    unsigned char Numb;
    SecretNumb = rand()%10+48;    

    while(i<counter)
    {
        Check = true;        
        Numb = rand()%10+48;
        for(int t=0; t<=i-1; t++)
        {
            if(Numb==SecretNumb[t])
                Check = false;

        }
        if(Check)
        {
            i++;
            SecretNumb += Numb;
        }


    }
    return SecretNumb;
}
//----------------------------------------------------------
std::wstring KeyNumb::Compare(std::wstring UserNumb)
{
    std::wstring Result;

    int Bull = 0;
    int Cow = 0;
    for(int i=0; i<counter; i++)
    {
        for(int t=0; t<counter; t++)
        {
            if(SecretNumb[i]==UserNumb[t])
            {
                if(t==i)
                    Bull++;
                else
                    Cow++;
            }
        }
    }
    return Result = IntToStr(Bull) + L"Б" + IntToStr(Cow) + L"К";
}
//---------------------------------------------------------
std::wstring KeyNumb::IntToStr(int numb)
{
    std::wstringstream s;
    s << numb;

    return s.str();
}

int KeyNumb::GetCounter()
{
    return counter;
}

//----------------------------------------------------------
bool MyDataBase::OpenDataBase(wchar_t* Name)
{
    if(sqlite3_open16(Name, &DB) != SQLITE_OK)
    {
        std::wcout<<L"Ошибка: "<<sqlite3_errmsg16(DB)<<std::endl;
        return(false);
    }
    else
        return(true);
}
//----------------------------------------------------------
void MyDataBase::CreateTable()
{
    const wchar_t* _SQLquery;

    _SQLquery = L"CREATE TABLE IF NOT EXISTS MyTable (number INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, password TEXT, try REAL, wins REAL, ratio REAL);";
    sqlite3_prepare16_v2(DB, _SQLquery, -1, &stmtU, 0);
        //std::wcout<<L"Ошибка подготовки SQL запроса: "<< sqlite3_extended_errcode(DB) <<std::endl;

    if(sqlite3_step(stmtU)!=SQLITE_DONE) //выполнить команду
        std::wcout<<L"Ошибка выполнения команды"<<std::endl;
    sqlite3_reset(stmtU);//сбросить команду
    sqlite3_finalize(stmtU);//очистить, завершить работу команды
}
//----------------------------------------------------------
bool MyDataBase::CreateUser(wchar_t* Name, wchar_t* passw)
{
    const wchar_t* _SQLquery;
    wchar_t* CheckName;
    bool Checked = true; //успешность проверки имени на совпадение

    _SQLquery = L"SELECT * FROM MyTable where name=?;";
    sqlite3_prepare16_v2(DB, _SQLquery, -1, &stmtU, NULL);
    sqlite3_bind_text16(stmtU, 1, Name, -1, 0);
    while(sqlite3_step(stmtU) == SQLITE_ROW)
    {
        CheckName = (wchar_t*)sqlite3_column_text16(stmtU, 1);
         if (CheckName != NULL)
         {
             Checked = false;
             break;//прерываем цикл.
         }

    }
    sqlite3_reset(stmtU);//сбросить команду
    sqlite3_finalize(stmtU);//очистить, завершить работу команды

    if(Checked)
    {
        _SQLquery = L"INSERT INTO MyTable(name, password, try, wins, ratio) VALUES(?,?,0,0,0);";
        sqlite3_prepare16(DB, _SQLquery, -1, &stmtU, 0);
        sqlite3_bind_text16(stmtU, 1, Name, -1, 0 );
        sqlite3_bind_text16(stmtU, 2, passw, -1, 0 );
        sqlite3_step(stmtU); //выполнить команду
        sqlite3_reset(stmtU);//сбросить команду
        sqlite3_finalize(stmtU);//очистить, завершить работу команды
        return(true);
    }
    else
        return(false);
}
//----------------------------------------------------------
bool MyDataBase::CheckUserLoginPass(wchar_t* Name, wchar_t* passw)
{
    const wchar_t* _SQLquery;
    wchar_t* CheckName = NULL;
    _SQLquery = L"SELECT * FROM MyTable where name=? AND password=?;";
    sqlite3_prepare16(DB, _SQLquery, -1, &stmtU, 0);
    sqlite3_bind_text16(stmtU, 1, Name, -1, 0);
    sqlite3_bind_text16(stmtU, 2, passw, -1, 0);
    while (sqlite3_step(stmtU) == SQLITE_ROW)
    {
        CheckName = (wchar_t*)sqlite3_column_text16(stmtU, 1);
        if (CheckName != NULL)
        {
            sqlite3_reset(stmtU);
            sqlite3_finalize(stmtU);
            return(true);
        }

    }
    sqlite3_reset(stmtU);
    sqlite3_finalize(stmtU);
    return(false); //ошибка!
}
//---------------------------------------------------------
void MyDataBase::GetData(wchar_t* Name)
{
    const wchar_t* _SQLquery;
    //wchar_t* CheckName;

    _SQLquery = L"SELECT * FROM MyTable WHERE name=?;";
    sqlite3_prepare16_v2(DB, _SQLquery, -1, &stmtU, NULL);
    sqlite3_bind_text16(stmtU, 1, Name, -1, 0);
    sqlite3_step(stmtU);
    Try = (int)sqlite3_column_double(stmtU, 3);
    Wins = (int)sqlite3_column_double(stmtU, 4);
    Ratio = (double)sqlite3_column_double(stmtU, 5);

    sqlite3_reset(stmtU);//сбросить команду
    sqlite3_finalize(stmtU);//очистить, завершить работу команды

    std::wcout<<std::endl<<L"Статистика игрока: "<<Name<<std::endl
    <<L"Чисел угадано: "<<Wins<<std::endl
    <<L"Среднее кол-во попыток: "<<Ratio<<std::endl<<std::endl;

}
//---------------------------------------------------------
void MyDataBase::SetData(double t, wchar_t* Name)
{
    const wchar_t* _SQLquery;
    Try += t;
    ++Wins;
    Ratio = Try/Wins;

    _SQLquery = L"UPDATE MyTable SET (try,wins,ratio) = (?,?,?) WHERE name=?;";
    sqlite3_prepare16_v2(DB, _SQLquery, -1, &stmtU, 0);
    sqlite3_bind_double(stmtU,1,Try);
    sqlite3_bind_double(stmtU,2,Wins);
    sqlite3_bind_double(stmtU,3,Ratio);
    sqlite3_bind_text16(stmtU, 4, Name, -1, 0);
    sqlite3_step(stmtU);
    sqlite3_reset(stmtU);//сбросить команду
    sqlite3_finalize(stmtU);//очистить, завершить работу команды
}

//----------------------------------------------------------
